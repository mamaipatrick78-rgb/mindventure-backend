# MindVenture production foundation
This package provides a runnable PostgreSQL + Node/Express API and a custody abstraction for BTC, ETH, USDT and SOL.

## Start
cp .env.example .env
docker compose up -d
docker compose exec api node src/migrate.js
API: http://localhost:4000/health

## Real custody
The included MockCustody is intentionally non-custodial/demo-only. Before accepting customer assets, replace it with an approved custody provider adapter and configure webhooks for blockchain confirmations.

A production withdrawal should be:
request -> authentication/2FA -> KYC/AML/risk screening -> balance lock -> policy/multisig approval -> custody signing -> broadcast -> confirmations -> reconcile -> release/complete.

Never store private keys in PostgreSQL. Use HSM/MPC/cold storage through the custody provider, least privilege, immutable audit logs, rate limits, webhook signature verification, address allowlisting and independent security testing.

## AI trading engine
Adds an opt-in, autonomous engine (`src/trading-engine.js`) that:
1. Pulls BTC/ETH/SOL price history from CoinGecko's free public API (`src/marketdata.js`).
2. Scores RSI, SMA20/50 crossover and 7-day momentum into a BUY/SELL/HOLD signal with a
   confidence score (`src/strategy.js`) — a transparent starting heuristic, not a
   validated or profitable strategy. Back-test before trusting it with real funds.
3. Optionally asks Claude to turn the signal into a plain-English note for the user's
   activity log (`src/ai-explain.js`); falls back to a template if `ANTHROPIC_API_KEY`
   is unset. The LLM never makes the trade decision, only explains one already made.
4. Executes by **rebalancing the user's own custodied balances** between an asset and
   USDT (`src/convert.js`) — there is no external exchange order routing in this
   codebase. "Autonomous trading" here means autonomous reallocation among assets the
   platform already holds for the user, not autonomous placement of live market orders.

Risk controls (`trading_settings` table, enforced both in the API and as hard DB `CHECK`
constraints so they can't be bypassed by a bad request): per-trade cap as % of balance,
max trades/day, a daily-loss circuit breaker that auto-disables trading for that user,
minimum confidence threshold, and a one-click kill switch
(`POST /api/trading/kill-switch`). Every decision — executed or skipped, and why — is
written to `ai_trade_decisions` for a full audit trail.

Defaults to `mode='paper'`. Nothing here connects to a real exchange or moves real
external crypto — see "Real custody" above for what that would additionally require.
Before letting this touch real customer funds: back-test the strategy on historical
data, load-test the daily-loss circuit breaker, and get the licensing question below
answered for discretionary/autonomous trading specifically (it is regulated separately
from, and typically more heavily than, custody/exchange services).

## Compliance
Because the proposed platform is an investment/crypto service, licensing and AML/KYC requirements must be settled before real customer funds are accepted. Kenya's Virtual Asset Service Providers Act 2025 is in force and the CMA publishes the VASP regulatory framework. Verify the exact licence and regulator for the final business model.

Autonomous/discretionary trading of customer assets (the AI trading engine above) is typically a separate regulated activity from custody/exchange (e.g. investment adviser, portfolio/fund manager or collective-investment-scheme rules, on top of VASP), with its own licence, disclosure and marketing-language requirements (avoid words like "guaranteed returns" or "safe profit" in any user-facing copy). Confirm this separately before enabling live mode for any real user.
